package com.example.shiftmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShiftmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
