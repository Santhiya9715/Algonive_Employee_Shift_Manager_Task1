package com.example.shiftmanager.service;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.shiftmanager.model.Employee;
import com.example.shiftmanager.model.Shift;
import com.example.shiftmanager.repository.EmployeeRepository;
import com.example.shiftmanager.repository.ShiftRepository;
@Service

public class ShiftService {
	private final ShiftRepository shiftRepo;
	private final EmployeeRepository empRepo;
	public ShiftService(ShiftRepository shiftRepo,EmployeeRepository empRepo) {
		this.shiftRepo=shiftRepo;
		this.empRepo=empRepo;
	}
	public Shift createShift(Shift s,Long employeeId) {
		if(employeeId!=null) {
			Employee e = empRepo.findById(employeeId).orElseThrow(() -> new 
					RuntimeException("Employee not found"));
			s.setAssignedEmployee(e);
		}
		return shiftRepo.save(s);
}
	public List<Shift> getAllShifts(){
		return shiftRepo.findAll();
	}
	public List<Shift> getShiftsForEmployee(Long employeeId){
		return shiftRepo.findByAssignedEmployeeId(employeeId);
	}

	}
	










