package com.example.shiftmanager.service;

import com.example.shiftmanager.model.Employee;
import com.example.shiftmanager.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service

public class EmployeeService {
	private final EmployeeRepository repo;
    public EmployeeService(EmployeeRepository repo) { this.repo = repo; }

    public Employee register(Employee e) {
        // simple check
        Optional<Employee> existing = repo.findByEmail(e.getEmail());
        if (existing.isPresent()) throw new RuntimeException("Email already exists");
        return repo.save(e);
    }

    public Optional<Employee> findByEmail(String email) {
        return repo.findByEmail(email);
    }

    public Optional<Employee> findById(Long id) { return repo.findById(id);
    }
}



