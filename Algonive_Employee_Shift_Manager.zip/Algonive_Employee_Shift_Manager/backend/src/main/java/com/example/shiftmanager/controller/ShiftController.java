package com.example.shiftmanager.controller;
import com.example.shiftmanager.model.Shift;
import com.example.shiftmanager.dto.CreateShiftRequest;
import com.example.shiftmanager.service.ShiftService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shifts")
@CrossOrigin(origins = "*")

public class ShiftController {
	private final ShiftService service;
    public ShiftController(ShiftService service) { this.service = service; }

    @PostMapping
    public Shift createShift(@RequestBody CreateShiftRequest req) {
        Shift s = new Shift();
        s.setStartTime(req.getStartTime());
        s.setEndTime(req.getEndTime());
        s.setNotes(null);
        return service.createShift(s, req.getEmployeeId());
    }

    @GetMapping
    public List<Shift> getAllShifts() { return service.getAllShifts(); }

    @GetMapping("/employee/{id}")
    public List<Shift>getShiftsForEmployee(@PathVariable Long id){
    	return service.getShiftsForEmployee(id);
    }
}
    


