package com.example.shiftmanager.controller;
import com.example.shiftmanager.model.Employee;
import com.example.shiftmanager.dto.EmployeeRegisterRequest;
import com.example.shiftmanager.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "*")


public class EmployeeController {
	 private final EmployeeService service;
	    public EmployeeController(EmployeeService service) { this.service = service; }

	    @PostMapping("/register")
	    public Employee register(@RequestBody EmployeeRegisterRequest req) {
	        Employee e = new Employee();
	        e.setName(req.getName());
	        e.setEmail(req.getEmail());
	        e.setPassword(req.getPassword()); // hash in real app
	        e.setRole(req.getRole() == null ? "EMPLOYEE" : req.getRole());
	        return service.register(e);
	    }

	    @PostMapping("/login")
	    public Employee login(@RequestBody EmployeeRegisterRequest req) {
	        return service.findByEmail(req.getEmail())
	            .filter(e -> e.getPassword().equals(req.getPassword()))
	            .orElseThrow(() -> new RuntimeException("Invalid credentials"));
	    }
	    
	    @GetMapping("/{id}")
	    public Employee getById(@PathVariable Long id) {
	    	return service.findById(id).orElseThrow();
	    }
	    
}

	    
	    
	    
	    
	    
	    


