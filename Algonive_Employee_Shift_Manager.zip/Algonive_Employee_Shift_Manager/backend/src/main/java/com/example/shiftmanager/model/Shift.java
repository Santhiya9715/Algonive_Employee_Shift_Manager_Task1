package com.example.shiftmanager.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "shifts")

public class Shift {
	 @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private LocalDateTime startTime;
	    private LocalDateTime endTime;

	    @ManyToOne
	    @JoinColumn(name="employee_id")
	    private Employee assignedEmployee; // nullable = unassigned

	    private String notes;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public LocalDateTime getStartTime() {
			return startTime;
		}

		public void setStartTime(LocalDateTime startTime) {
			this.startTime = startTime;
		}

		public LocalDateTime getEndTime() {
			return endTime;
		}

		public void setEndTime(LocalDateTime endTime) {
			this.endTime = endTime;
		}

		public Employee getAssignedEmployee() {
			return assignedEmployee;
		}

		public void setAssignedEmployee(Employee assignedEmployee) {
			this.assignedEmployee = assignedEmployee;
		}

		public String getNotes() {
			return notes;
		}

		public void setNotes(String notes) {
			this.notes = notes;
		}

		public Shift() {
			super();
			// TODO Auto-generated constructor stub
		}


}
