package com.example.shiftmanager.repository;
import com.example.shiftmanager.model.Shift;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ShiftRepository  extends JpaRepository<Shift, Long> {
    List<Shift> findByAssignedEmployeeId(Long employeeId);
} 
