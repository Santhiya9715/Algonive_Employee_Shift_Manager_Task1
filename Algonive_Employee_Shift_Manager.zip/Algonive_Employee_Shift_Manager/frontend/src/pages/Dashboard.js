import React from "react";
import "../styles/styles.css";

function Dashboard() {
  return (
    <div className="dashboard-container">
      <h1>Welcome to Dashboard</h1>

      <div className="dashboard-box">
        <p>This is your dashboard page.</p>
        <p>You can add more features here later.</p>
      </div>
    </div>
  );
}

export default Dashboard;
