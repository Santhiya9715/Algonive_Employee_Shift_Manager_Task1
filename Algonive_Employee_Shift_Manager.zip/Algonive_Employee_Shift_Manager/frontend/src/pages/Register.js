import axios from "axios";
import API from "../api";
import "../styles/styles.css";
import React, { useState } from "react";

export function registerEmployee(data) {
    return axios.post(`${API_BASE_URL}/api/employee/register`, data);
}

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = (e) => {
    e.preventDefault();

    if (name.trim().length === 0) {
      setError("Name is required.");
      return;
    }
     const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    setError("");
    alert("Registration Successful (Validation OK)");
  };

  return (
    <div className="form-container">
      <h2>Create Account</h2>

      {error && <p className="error-message">{error}</p>}

      <form onSubmit={handleRegister}>
        <input
          type="text"
          placeholder="Enter Full Name"
          value={name}
           onChange={(e) => setName(e.target.value)}
        />

        <input
          type="email"
          placeholder="Enter Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button className="btn" type="submit">
          Register
        </button>
      </form>
        <div className="form-link">
        <p>
          Already have an account? <a href="/login">Login</a>
        </p>
      </div>
    </div>
  );
}

export default Register;

    
        
    