export function createShift(data) {
    return axios.post(`${API_BASE_URL}/api/shift/create`, data);
}
import React from "react";
import Navbar from "../components/Navbar";
import ShiftCard from "../components/Shiftcard";
import "../styles/styles.css";

function Shifts() {
  const shifts = [
    { employee: "John", date: "2025-01-01", time: "09:00 - 17:00" },
    { employee: "Emma", date: "2025-01-01", time: "10:00 - 18:00" }
  ];

  return (
    <div>
      <Navbar />
      <div className="page-container">
        <h1>Shifts</h1>

        <div className="shifts-list">
          {shifts.map((s, i) => (
            <ShiftCard key={i} shift={s} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default Shifts;