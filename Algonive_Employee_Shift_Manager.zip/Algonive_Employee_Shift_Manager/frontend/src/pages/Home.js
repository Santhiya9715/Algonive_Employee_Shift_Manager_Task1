import React from "react";
import "../styles/styles.css";

function Home() {
  return (
    <div className="home-container">
      <h1>Welcome to Shift Manager</h1>
      <p>Manage your shifts easily and efficiently.</p>

      <div className="home-buttons">
        <a href="/login" className="btn">Login</a>
        <a href="/register" className="btn">Register</a>
      </div>
    </div>
  );
}

export default Home;