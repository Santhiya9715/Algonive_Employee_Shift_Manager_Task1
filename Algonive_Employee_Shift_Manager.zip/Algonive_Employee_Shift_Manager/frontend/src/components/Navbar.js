import React from "react";
import { Link } from "react-router-dom";
import "../styles/styles.css";

function Navbar() {
  return (
    <nav className="navbar">
      <div className="nav-brand">Shift Manager</div>

      <ul className="nav-links">
        <li><Link to="/login">Login</Link></li>
        <li><Link to="/register">Register</Link></li>
        <li><Link to="/dashboard">Dashboard</Link></li>
      </ul>
    </nav>
  );
}

export default Navbar;
