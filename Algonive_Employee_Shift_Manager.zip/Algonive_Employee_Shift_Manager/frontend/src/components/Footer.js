import React from "react";
import "../styles/styles.css";

function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Shift Manager. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;