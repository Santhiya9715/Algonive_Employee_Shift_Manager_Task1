import React from "react";
import "../styles/styles.css";

function Shiftcard({ shift }) {
  return (
    <div className="shift-card">
      <h3>{shift.employee}</h3>
      <p>Date: {shift.date}</p>
      <p>Time: {shift.time}</p>
    </div>
  );
}

export default Shiftcard;